#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libusb-1.0/libusb.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <sys/ioctl.h>
int gadget_init();
void gadgetFile_renew(const char informacionPresenteDeJoyStick, const char informacionAnteriorDeJoyStick, int uinputFD);

void find_gator_gadget(libusb_device *device, libusb_device **gator_gadget);
void continualy_Polling_Driver(libusb_context *context_data_info, libusb_device ***catalog_of_devices_ptr, libusb_device **gator_gadget);

#define PRODUCT_ID_OF_GATOR_GADGET 47639
#define VENDOR_ID_OF_GATOR_GADGET 39546
int main()
{

    libusb_context *context_data_info = NULL; // ptr to a libusb session
    int valor_to_check_back;
    valor_to_check_back = libusb_init(&context_data_info);
    if (valor_to_check_back < 0){
        printf("ERR DETECTION: libusb init blunder\n");
        return 1;
    }
    libusb_set_debug(context_data_info, 3);
    libusb_device *gator_gadget = NULL; // pointer to the gator gadget or device
    libusb_device **catalog_of_devices = NULL; // ptr to usb devices that are in an agenda or list
    ssize_t deviceQuantity; //quantity of usb devices in catalog_of_devices
    deviceQuantity = libusb_get_device_list(context_data_info, &catalog_of_devices);//get quantity of gadgets used in the form of a list
    if (deviceQuantity < 0)
        printf("ERR DETECTION: it was not possible for the devices to be obtained\n");
    ssize_t device_lista; //deviceList
    device_lista = 0;
    while(device_lista < deviceQuantity){
      printf("\n----- device %zd -----\n", device_lista+1);
      find_gator_gadget(catalog_of_devices[device_lista], &gator_gadget);
      device_lista++;
    }
    if (gator_gadget == NULL){
        printf("\nERR DETECTION: the Gator_Gadget device is NULL and so it cannot be found.\n\n");
        return 1;
    }
    continualy_Polling_Driver(context_data_info, &catalog_of_devices, &gator_gadget);
    //the devices catalog is released & unreferenced. To be done in Future by above function
    libusb_exit(context_data_info);
    //exit appropriately and return
    return 0;
}

int gadget_init()
{
    int uinputFD = -100; //just for emphasis to make it negative
    uinputFD = open("/dev/uinput", ( O_WRONLY | O_NONBLOCK ));
    if (uinputFD < 0)
        return -1;
    ioctl(uinputFD, UI_SET_EVBIT, EV_KEY); //allows key press/release events
    ioctl(uinputFD, UI_SET_KEYBIT, BTN_JOYSTICK); //setting buttons that are allowed to be used
    ioctl(uinputFD, UI_SET_EVBIT, EV_ABS); //enable absolute axes events & setting gamepad sticks
    ioctl(uinputFD, UI_SET_ABSBIT, ABS_X); //set absolute X-axis to be used
    ioctl(uinputFD, UI_SET_ABSBIT, ABS_Y);//set absolute Y-axis to be used

    struct uinput_user_dev usetup;
    memset(&usetup,0,sizeof(usetup));
    snprintf(usetup.name,UINPUT_MAX_NAME_SIZE,"Gator_Gadget");
    usetup.id.bustype = BUS_USB;
    usetup.id.vendor = 0x9A7A;
    usetup.id.product = 0xBA17;
    usetup.id.version = 1;
    write(uinputFD, &usetup, sizeof(usetup));
    ioctl(uinputFD, UI_DEV_CREATE);
    return uinputFD;
}

//update device file
void gadgetFile_renew(const char informacionPresenteDeJoyStick, const char informacionAnteriorDeJoyStick, int uinputFD)
{
    struct input_event event_input;
    int stateRenewed_Btn = informacionPresenteDeJoyStick / 16;//button_updated_state
    int stateRenewed_Y = informacionPresenteDeJoyStick % 4;//y_axis_updated_state
    int stateRenewed_X = (informacionPresenteDeJoyStick / 4) % 4;//x_axis_updated_state
    if ((informacionAnteriorDeJoyStick / 16) != stateRenewed_Btn) //renew info about btn
    {
        memset(&event_input, 0, sizeof(event_input));
        event_input.type = EV_KEY;
        event_input.value = stateRenewed_Btn;
        event_input.code = BTN_JOYSTICK;
        write(uinputFD, &event_input, sizeof(event_input));
        event_input.type = EV_SYN;
        event_input.value = 0;
        event_input.code = 0;
        write(uinputFD, &event_input, sizeof(event_input));
    }

    if (((informacionAnteriorDeJoyStick / 4) % 4) != stateRenewed_X) //renew info for X-axis
    {
        memset(&event_input, 0, sizeof(event_input));
        event_input.type = EV_ABS;
        if(stateRenewed_X == 1)
          event_input.value = -32767;
        else if(stateRenewed_X == 2)
          event_input.value = 0;
        else if(stateRenewed_X == 3)
          event_input.value = 32767;
        event_input.code = ABS_X;
        write(uinputFD, &event_input, sizeof(event_input));
        event_input.type = EV_SYN;
        event_input.value = 0;
        event_input.code = 0;
        write(uinputFD, &event_input, sizeof(event_input));
    }

    if ((informacionAnteriorDeJoyStick % 4) != stateRenewed_Y) //renew info for Y-axis
    {
        memset(&event_input, 0, sizeof(event_input));
        event_input.type = EV_ABS;
        if(stateRenewed_Y == 1)
          event_input.value = 32767;
        else if(stateRenewed_Y == 2)
          event_input.value = 0;
        else if(stateRenewed_Y == 3)
          event_input.value = -32767;
        event_input.code = ABS_Y;
        write(uinputFD, &event_input, sizeof(event_input));
        event_input.type = EV_SYN;
        event_input.value = 0;
        event_input.code = 0;
        write(uinputFD, &event_input, sizeof(event_input));
    }
}

void continualy_Polling_Driver(libusb_context *context_data_info, libusb_device ***catalog_of_devices_ptr, libusb_device **gator_gadget)
{
    int valor_zero = 0;
    int valor_one = 1;
    int uinputFD = -100; //just for emphasis to make it negative
    int theSuccessInOpeningUInput = 1;//if success in opening uinput
    int valor_to_check_back;
    int quantityBytesRelocated = -10;
    libusb_device_handle *maneaveur_the_gadget = NULL;
    struct libusb_config_descriptor *config_descriptor = NULL;
    const struct libusb_interface *interface_ptr = NULL;
    const struct libusb_interface_descriptor *interdesc = NULL;
    const struct libusb_endpoint_descriptor *epdesc = NULL;
    unsigned char *informationFromJoyStick = (unsigned char *)malloc(sizeof(char));
    int *quantityBytesRelocated_ptr;
    quantityBytesRelocated_ptr = &quantityBytesRelocated;
    maneaveur_the_gadget = libusb_open_device_with_vid_pid(context_data_info, VENDOR_ID_OF_GATOR_GADGET, PRODUCT_ID_OF_GATOR_GADGET);
    //we progress forward with achieving endpt addr

    libusb_get_config_descriptor(*gator_gadget, valor_zero, &config_descriptor);
    if ((int)config_descriptor->bNumInterfaces != valor_one)
        printf("\nWARNING: Gator_Gadget's quantity of interfaces != 1\n\n");

    interface_ptr = &config_descriptor->interface[valor_zero];
    if (interface_ptr->num_altsetting != valor_one)
        printf("\nWARNING: First Interface's quantity of alternate settings != 1\n\n");

    interdesc = &interface_ptr->altsetting[valor_zero];
    if (interdesc->bNumEndpoints != valor_one)
        printf("\nWARNING: First Interface's & First Alternate Settings' quantity of endpoints != 1\n\n");

    epdesc = &interdesc->endpoint[valor_zero];
    int endpoint_address = (int)epdesc->bEndpointAddress;

    //the devices catalog is released before GatorGadget is worked on
    *gator_gadget = NULL; interdesc = NULL; epdesc = NULL;  interface_ptr = NULL;
    libusb_free_device_list(*catalog_of_devices_ptr, 1);
    valor_to_check_back = libusb_claim_interface(maneaveur_the_gadget, 0);
    if (valor_to_check_back != valor_zero && maneaveur_the_gadget != NULL){
        libusb_close(maneaveur_the_gadget);
        printf("\nERR DETECTION: Device Interface was unsuccessfully claimed\n\n");
        return;
    }

    if (maneaveur_the_gadget == NULL){
        printf("\nERR DETECTION: Gator_Gadget device was not able to be opened\n\n");
        return;
    }

    if (libusb_kernel_driver_active(maneaveur_the_gadget, 0)) //does device have a kernel driver attached to it?
    {                                                         //if so, there try to detach it
        valor_to_check_back = libusb_detach_kernel_driver(maneaveur_the_gadget, 0);
        if (valor_to_check_back != valor_zero){
            libusb_close(maneaveur_the_gadget);
            printf("\nERR DETECTION: Gator_Gadget device was discovered to have a kernel driver attached to it that unsuccessfully, could not detach\n\n");
            return;
        }
        else
          ;
    }
    char informacionAnteriorDeJoyStick = (char)0x00000;
    uinputFD = gadget_init();
    if (uinputFD < 0){ //failed to open fd to uinput
        theSuccessInOpeningUInput = valor_zero;
        printf("\nERR DETECTION: unsuccessfully tried openning input device file in userspace\n\n");
        //printf("ERR: you have failed with in the uinput");
    }
    while (theSuccessInOpeningUInput){
        valor_to_check_back = libusb_interrupt_transfer(maneaveur_the_gadget, endpoint_address, informationFromJoyStick, 1, quantityBytesRelocated_ptr, 0);
        if (*quantityBytesRelocated_ptr >= valor_one){
          // utilize data from that of joystick and you can update the device file of joystick
          gadgetFile_renew( (const char)(*informationFromJoyStick), (const char)informacionAnteriorDeJoyStick, uinputFD);
          informacionAnteriorDeJoyStick = *informationFromJoyStick;
        }
        else
            printf("\nWARNING: the quantity of bytes < 1 was transferred in the most recent poll\n\n");

    }

    valor_to_check_back = libusb_release_interface(maneaveur_the_gadget, 0);
    if (valor_to_check_back == valor_zero)
      libusb_close(maneaveur_the_gadget);//always close
    else{
      printf("\nERR DETECTION: device interface was unable to be released\n\n");
      libusb_close(maneaveur_the_gadget);
      return;
    }
}

void find_gator_gadget(libusb_device *device, libusb_device **gator_gadget)
{
    struct libusb_device_descriptor device_descriptor;
    int valor_to_check_back = libusb_get_device_descriptor(device, &device_descriptor);
    if (valor_to_check_back < 0){
        printf("(Failed to get device descriptor)\n");
        return;
    }
    const struct libusb_endpoint_descriptor *epdesc;
    const struct libusb_interface *inter;
    const struct libusb_interface_descriptor *interdesc;
    if ((device_descriptor.idVendor == VENDOR_ID_OF_GATOR_GADGET) && (device_descriptor.idProduct == PRODUCT_ID_OF_GATOR_GADGET))
        *gator_gadget = device;
    printf("Quantity of Possible Configurations: %d\n", device_descriptor.bDeviceClass);
    struct libusb_config_descriptor *config_descriptor;
    libusb_get_config_descriptor(device, 0, &config_descriptor);

    printf("Product ID: %d\n", device_descriptor.idProduct);
    printf("Vendor ID: %d\n", device_descriptor.idVendor);
    printf("Quantity of Interfaces: %d ||| \n", (int)config_descriptor->bNumInterfaces);
    for(int i = 0; i < (int)config_descriptor->bNumInterfaces; i++)
    {
        inter = &config_descriptor->interface[i];
        printf("Quantity of Alternate Settings: %d | \n", inter->num_altsetting);
        for(int j = 0; j < inter->num_altsetting; j++)
        {
            interdesc = &inter->altsetting[j];
            printf("Interface Number: %d | \nQuantity of Endpoints: %d | \n", (int)interdesc->bInterfaceNumber, (int)interdesc->bNumEndpoints);
            for (int k = 0; k < (int)interdesc->bNumEndpoints; k++)
            {
                epdesc = &interdesc->endpoint[k];//EP == Endpoint
                printf("Descriptor Type: %d | \nEP Address: %d | \n", (int)epdesc->bDescriptorType, (int)epdesc->bEndpointAddress);
            }
        }
    }
    printf("\n\n");
    libusb_free_config_descriptor(config_descriptor);
}

