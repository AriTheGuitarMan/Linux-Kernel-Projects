#define _GNU_SOURCE
#include <stdio.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>

int set_security_level (int pid, int new_level){
	return syscall(332, pid, new_level);
}

int get_security_level (int pid){
	return syscall(333, pid);
}

int* retrieve_set_security_params (int pid, int new_level){
	int *array = (int *)malloc(4*(sizeof(int)));
	array [0]= 332;	array [1] = 2; array [2] = pid; array [3] = new_level;
	return array;
}

int* retrieve_get_security_params (int pid){
	int *array = (int *)malloc(3*(sizeof(int)));
	array[0] = 333;	array[1] = 1; array[2] = pid;
	return array;
}

int interpret_set_security_result (int ret_value){
	return ret_value;
}

int interpret_get_security_result (int ret_value){
	return ret_value;
}
