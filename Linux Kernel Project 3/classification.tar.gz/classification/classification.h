#ifndef CLASSIFICATION_H
#define CLASSIFICATION_H
#define _GNU_SOURCE

#include <stdio.h>
#include <linux/unistd.h>
#include <sys/syscall.h>
#define sys_set_classification 332
#define sys_get_classification 333

//Invokes system call which attempts to change the file identified by filename to classification new_class.
//Returns new_class on success, and -1 otherwise.
int set_classification (const char *filename, int new_class);

//Invokes system call which reads the classification of the process identified by filename.
//Returns the access level on success, and -1 otherwise.
int get_classification (const char *filename);

#endif
